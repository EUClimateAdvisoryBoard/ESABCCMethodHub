# EU scenario pathways: six sectors, 2040 screening settings

Internal. Contains Scenario Compass v2.0 data (embargo): do not upload to external services or public repositories.

## data/
- `all_pathways_1328.csv`: one row per pathway (source, model, scenario).
  - Screening inputs: net50, red40, ESABCC filter variables, industry i20–i50.
  - Stage per setting, in columns `nz{0|150}|{window}|m{0|10}`. Codes: -1 no industry data, 0 fails net-GHG rule, 1 outside 2040 window, 2 fails ESABCC filter, 3 above a risk level, 4 within all criteria.
  - Sector values for 2020/30/40/50, and EU net GHG 2020–2050 (`net_ghg_*`, as reported).
- `advice_setting_64_pathways.csv`: the 64 pathways within all criteria under net GHG ≤ 150 Mt and 85–95% (column `nz150|85–95%|m0` == 4).
- `sector_medians_by_setting.csv`: n, 2040 and 2050 median, and 5/95% per sector and setting (margin 0).
- `inventory_sectors_2005_2024.csv`, `inventory_eu_net_ghg_1990_2024.csv`: EEA inventory.
- `funnel_advice_setting.json`: counts per screening step and the sources of the 64.

## Column prefixes and units
| Prefix | Content | Unit |
|---|---|---|
| `sup_e` | energy supply CO2 | Mt |
| `sup_wind`, `sup_solar`, `sup_el` | electricity | TWh, converted from EJ × 277.78 |
| `sup_h2` | hydrogen production | EJ |
| `mob_` | mobility | — |
| `bui_` | buildings | — |
| `agr_ch4` | agriculture CH4 | Mt |
| `agr_n2o` | agriculture N2O | kt |
| `agr_co2e` | agriculture CO2e (CH4 × 28, N2O × 0.265; AR5) | Mt |
| `eco_e` | LULUCF CO2 | Mt |
| `eco_forest` | forest area | Mha |
| `fe40`, `el40`, `h240` | industry final energy, electricity, hydrogen in 2040 | EJ |
| `ccs50` | CO2 captured in industry in 2050 | Mt |
| `i20`–`i50` | industry GHG harmonised to the 2020 inventory | Mt CO2e |

Final energy columns are in EJ. Only industry is harmonised; the other sectors are as reported. EU net GHG regions differ across models (EU27, EU27 and UK).

## scripts/
The fetch and screening scripts (pyam / ixmp4) and the chart and deck scripts (`charts.py`, `charts2.py`, `econ.py`, `build.py`). Paths inside point to the original working folders and need adjusting.

## charts/, deck/
PNG charts and the presented HTML deck (arrow keys to navigate).
