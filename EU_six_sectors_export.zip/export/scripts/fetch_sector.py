import pyam, ixmp4, re, sys, time, pandas as pd, warnings; warnings.filterwarnings('ignore')
PAT=re.compile(r'^(EU27|EU27 & UK|EU27 \(\*\)|EU27 & UK \(\*\)|European Union|European Union and United Kingdom|European Union \(R9\)|EU|EU28|EU27\+UK|EU-27|.*\|(EU ?27|EU ?28|EU27 and UK|European Union|EU & UK|EU))$')
VARS=["Emissions|CO2|Energy|Supply","Emissions|CO2|Energy|Supply|Electricity","Emissions|CO2|Energy|Demand|Transportation","Emissions|CO2|Energy|Demand|Residential and Commercial",
"Emissions|CO2|Energy|Demand|Industry","Emissions|CO2|Industrial Processes","Emissions|CH4|AFOLU","Emissions|N2O|AFOLU","Emissions|CH4|AFOLU|Agriculture","Emissions|N2O|AFOLU|Agriculture","Emissions|CO2|AFOLU",
"Emissions|Kyoto Gases|AFOLU","Emissions|CO2|Energy|Demand|AFOFI",
"Secondary Energy|Electricity","Secondary Energy|Electricity|Wind","Secondary Energy|Electricity|Solar","Secondary Energy|Electricity|Nuclear","Secondary Energy|Electricity|Coal","Secondary Energy|Electricity|Gas","Secondary Energy|Hydrogen",
"Final Energy|Industry","Final Energy|Industry|Electricity","Final Energy|Industry|Hydrogen","Final Energy|Transportation","Final Energy|Transportation|Electricity","Final Energy|Transportation|Hydrogen","Final Energy|Transportation|Liquids",
"Final Energy|Residential and Commercial","Final Energy|Residential and Commercial|Electricity","Final Energy|Residential and Commercial|Gases","Final Energy|Residential and Commercial|Heat",
"Food Energy Supply","Food Energy Supply|Livestock","Agricultural Production|Livestock","Land Cover|Cropland","Land Cover|Pasture","Land Cover|Forest","Land Cover|Forest|Afforestation and Reforestation","Carbon Removal|Land Use"]
slug, kind = sys.argv[1], sys.argv[2]; t=time.time()
if kind=='ixmp4':
    p=ixmp4.Platform(slug); regs=[n for n in p.regions.tabulate()['name'] if PAT.match(n)]
    allv=set(p.iamc.variables.tabulate()['name']); V=[v for v in VARS if v in allv]
    df=pyam.read_ixmp4(slug, region=regs, variable=V); df=df.filter(year=[2020,2030,2040,2050]) if df is not None else df
else:
    c=pyam.iiasa.Connection(slug); regs=[r for r in c.regions() if PAT.match(r)]
    allv=set(c.variables()); V=[v for v in VARS if v in allv]
    df=c.query(region=regs, variable=V); df=df.filter(year=[2020,2030,2040,2050])
d=df.data if df is not None else pd.DataFrame()
d.to_csv(f'sec_{slug}.csv', index=False)
print(slug, len(V), 'vars on platform;', len(d), 'rows', f'{time.time()-t:.0f}s', flush=True)
