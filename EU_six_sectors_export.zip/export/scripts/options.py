import json, glob, re, pandas as pd, numpy as np
exec(open("sector_avail.py").read().split("rows = []")[0].replace("sec_*.csv", "opts_*.csv").replace("slug = f[4:-4]", "slug = f[5:-4]"))
SPEC = [('fe40', 'Industry final energy', 'EJ', 2040, [['Final Energy|Industry']], [['FE|++|Industry']]),
        ('el40', 'Electricity in industry', 'EJ', 2040, [['Final Energy|Industry|Electricity']], [['FE|Industry|+|Electricity']]),
        ('h240', 'Hydrogen in industry', 'EJ', 2040, [['Final Energy|Industry|Hydrogen']], [['FE|Industry|+|Hydrogen']]),
        ('ccs50', 'CO₂ captured in industry', 'Mt CO₂', 2050, [['Carbon Capture|Industry'], ['Carbon Capture|Industrial Processes'], ['Carbon Sequestration|CCS|Industrial Processes']],
         [['Carbon Management|Carbon Capture|+|Industry Energy', 'Carbon Management|Carbon Capture|+|Industry Process']]),
        ('pr40', 'Industrial process CO₂', 'Mt CO₂', 2040, [['Emissions|CO2|Industrial Processes']], [['Emi|CO2|+|Industrial Processes']])]
def get(d, alts, y):
    for a in alts:
        if all(v in d and d[v].get(y) is not None and not (isinstance(d[v].get(y), float) and np.isnan(d[v].get(y))) for v in a):
            return sum(float(d[v][y]) for v in a), ' + '.join(a)
    return None, None
V = pd.read_csv('variants_all.csv')
out = []
for l, (_, vr) in zip(L, V.iterrows()):
    assert l['scenario'] == vr.scenario
    d = data_for(l) or {}
    rec = {}
    for k, lab, u, y, ia, rm in SPEC:
        val, var = get(d, rm if l['src'] in ('Schreyer', 'ElecH2') else ia, y); rec[k] = (val / 1000 if (val is not None and l['src'] == 'deeds' and k.startswith('fe')) else val); rec[k + '_var'] = var
    out.append(rec)
O = pd.concat([V, pd.DataFrame(out)], axis=1); O.to_csv('options_all.csv', index=False)
keys = [c for c in V.columns if c.startswith('nz')]
res = {}
for key in keys:
    P = O[O[key] == 4]; r = {'n': len(P)}
    for k, lab, u, y, ia, rm in SPEC:
        v = P[k].dropna(); r[k] = [round(v.min(), 2), round(v.median(), 2), round(v.max(), 2), len(v)] if len(v) else None
    res[key] = r; print(key, r)
json.dump(dict(res=res, spec=[(k, lab, u, y) for k, lab, u, y, _, _ in SPEC]), open('options.json', 'w'), default=float, ensure_ascii=False)
print(O.ccs50_var.value_counts().head())
