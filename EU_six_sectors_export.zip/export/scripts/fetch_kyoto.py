import pyam, ixmp4, re, sys, time, pandas as pd, warnings; warnings.filterwarnings('ignore')
PAT=re.compile(r'^(EU27|EU27 & UK|EU27 \(\*\)|EU27 & UK \(\*\)|European Union|European Union and United Kingdom|European Union \(R9\)|EU|EU28|EU27\+UK|EU-27|.*\|(EU ?27|EU ?28|EU27 and UK|European Union|EU & UK|EU))$')
VARS=["Emissions|Kyoto Gases"]
slug, kind = sys.argv[1], sys.argv[2]; t=time.time()
if kind=='ixmp4':
    p=ixmp4.Platform(slug); regs=[n for n in p.regions.tabulate()['name'] if PAT.match(n)]
    allv=set(p.iamc.variables.tabulate()['name']); V=[v for v in VARS if v in allv]
    df=pyam.read_ixmp4(slug, region=regs, variable=V); df=df.filter(year=[2015,2020,2040,2050]) if df is not None else df
else:
    c=pyam.iiasa.Connection(slug); regs=[r for r in c.regions() if PAT.match(r)]
    allv=set(c.variables()); V=[v for v in VARS if v in allv]
    df=c.query(region=regs, variable=V); df=df.filter(year=[2015,2020,2040,2050])
d=df.data if df is not None else pd.DataFrame()
d.to_csv(f'kyoto_{slug}.csv', index=False)
print(slug, len(V), 'vars on platform;', len(d), 'rows', f'{time.time()-t:.0f}s', flush=True)
