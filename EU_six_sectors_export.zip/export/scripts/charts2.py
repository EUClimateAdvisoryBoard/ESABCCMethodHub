exec(open('charts.py').read().split('OUT = {}')[0])
AD = 'nz150|85–95%|m0'; OUT = json.load(open('out.json')); L = {}
def med50(o):
    return o.get('med50', float(np.median(o['vals50'])) if o.get('vals50') else np.nan)
for sk, (name, unit, yl) in SEC.items():
    M = E_[[f'{sk}_{y}' for y in Y]].values; P = M[(S[AD].values == 4) & ~np.isnan(M).any(axis=1)]
    q = {p: np.percentile(P, p, axis=0) for p in (5, 25, 50, 75, 95)}
    meds = [med50(OUT[sk][KEY(v)]) for v in VAR]; lo, hi = np.nanmin(meds), np.nanmax(meds)
    L[sk] = dict(n=len(P), med50=q[50][3], p25=q[25][3], p75=q[75][3], lo=lo, hi=hi, med40=q[50][2], inv24=H[2024][sk])
    f, ax = plt.subplots(figsize=(17, 7.4))
    ax.bar(list(H), [H[y][sk] for y in H], color='#cfdde0', width=0.8, zorder=1, label='EEA inventory 2005–2024')
    ax.fill_between(Y, q[5], q[95], color=TEALL, alpha=0.45, lw=0, zorder=2, label='5–95%')
    ax.fill_between(Y, q[25], q[75], color=TEAL, alpha=0.75, lw=0, zorder=3, label='25–75%')
    ax.plot(Y, q[50], color=PURP, lw=3.5, zorder=4, label=f'median of the {len(P)} filtered pathways')
    for i, y in enumerate(Y[1:], 1): ax.text(y, q[50][i] + (yl[1] - yl[0]) * 0.025, f'{q[50][i]:,.0f}', ha='center', va='bottom', fontsize=17, fontweight='bold', color=PURP, zorder=6)
    ax.plot([2053.2, 2053.2], [lo, hi], color=ORANGE, lw=9, solid_capstyle='butt', zorder=5)
    ax.text(2054.2, (lo + hi) / 2, f'2050 median\nacross the six\nsettings:\n{lo:,.0f} to {hi:,.0f}', va='center', fontsize=15, fontweight='bold', color=ORANGE)
    ax.axhline(0, color='#1f1f1f', lw=0.8); ax.set_ylim(*yl); ax.set_xlim(2004, 2061); ax.set_xticks([2005, 2010, 2015, 2020, 2030, 2040, 2050]); ax.set_ylabel(unit)
    ax.legend(loc='upper right', bbox_to_anchor=(0.86, 1), frameon=False, fontsize=13)
    plt.tight_layout(); f.savefig(f'{sk}_main.png', dpi=120, transparent=True); plt.close(f)
# settings overview
W = ['85–90%', '85–95%', '≥ 85%']
f, axs = plt.subplots(2, 3, figsize=(17.5, 8.8))
for ax, (sk, (name, unit, yl)) in zip(axs.flat, SEC.items()):
    rows = [(nz, w) for nz in ('0', '150') for w in W]; vals = []
    for i, (nz, w) in enumerate(rows):
        k = f'nz{nz}|{w}|m0'; o = OUT[sk][k]; m = med50(o); col = PURP if nz == '0' else TEAL; yy = 5 - i
        if o['n'] == 0 or np.isnan(m): continue
        vals.append(m); P = o
        if 'p5_50' in o: ax.plot([np.nan], [np.nan])
        ax.scatter([m], [yy], s=200, color=col, zorder=3, edgecolor=(ORANGE if k == AD else 'none'), linewidth=4)
        ax.text(1.0, yy, f'{m:,.0f}  (n={o["n"]})', transform=ax.get_yaxis_transform(), fontsize=13, fontweight='bold', color=col, va='center', ha='right')
    lo, hi = min(vals + [0]), max(vals + [0]); pad = (hi - lo) * 0.12 + 5
    ax.set_xlim(lo - pad, hi + (hi - lo) * 0.75 + 30); ax.axvline(0, color='#1f1f1f', lw=0.8); ax.axhline(2.5, color='#d0d0d0', lw=1)
    ax.set_yticks(range(6)); ax.set_yticklabels([('≤ 0 · ' if nz == '0' else '≤ 150 · ') + w for nz, w in rows][::-1], fontsize=12.5)
    ax.set_ylim(-0.6, 5.6); ax.spines['left'].set_visible(False); ax.tick_params(axis='y', length=0)
    ax.set_title(name, loc='left', fontsize=17, fontweight='bold', color=TEALD); ax.set_xlabel(unit.split(' (')[0], fontsize=12)
plt.tight_layout(h_pad=2.2, w_pad=2); f.savefig('settings_all.png', dpi=120, transparent=True); plt.close(f)
# levers: medians 2020 and 2050 (industry energy 2040) in the advice set
F = S[S[AD] == 4]
LV = {'supply': [('Wind electricity', 'sup_wind', 'EJ'), ('Solar electricity', 'sup_solar', 'EJ'), ('Hydrogen production', 'sup_h2', 'EJ')],
      'industry': [('Electricity use', 'el40', 'EJ'), ('Hydrogen use', 'h240', 'EJ'), ('CO₂ captured', 'ccs50', 'Mt CO₂')],
      'mobility': [('Final energy', 'mob_fe', 'EJ'), ('Electricity use', 'mob_el', 'EJ'), ('Hydrogen use', 'mob_h2', 'EJ')],
      'buildings': [('Final energy', 'bui_fe', 'EJ'), ('Electricity use', 'bui_el', 'EJ'), ('Gas use', 'bui_gas', 'EJ')],
      'agri': [('Methane', 'agr_ch4', 'Mt CH₄'), ('Nitrous oxide', 'agr_n2o', 'kt N₂O'), ('Livestock food supply', 'agr_live', 'kcal')],
      'eco': [('Forest area', 'eco_forest', 'Mha'), ('LULUCF CO₂', 'eco_e', 'Mt CO₂')]}
LEV = {}
for sk, items in LV.items():
    LEV[sk] = []
    for lab, c, u in items:
        if c in ('el40', 'h240', 'ccs50'):
            v = F[c].dropna(); LEV[sk].append(dict(lab=lab, u=u, y=('2040' if c != 'ccs50' else '2050'), n=len(v), a=None, b=float(v.median()) if len(v) else None)); continue
        d = F[[f'{c}_2020', f'{c}_2050']].dropna()
        LEV[sk].append(dict(lab=lab, u=u, y='2050', n=len(d), a=float(d.iloc[:, 0].median()) if len(d) else None, b=float(d.iloc[:, 1].median()) if len(d) else None))
json.dump({'L': L, 'LEV': LEV}, open('out2.json', 'w'), indent=1, default=float)
for k in L: print(k, {kk: round(v, 1) for kk, v in L[k].items()}); print('  ', LEV[k])
