import json, glob, re, pandas as pd, numpy as np, collections
exec(open("sector_avail.py").read().split("rows = []")[0].replace("sec_*.csv", "kyoto_*.csv").replace("slug = f[4:-4]", "slug = f[6:-4]").replace("d = d[d.year.isin([2020, 2030, 2040, 2050])]", "d = d[d.year.isin([2015, 2020, 2040, 2050])]"))
H = json.load(open('/home/claude/figs/eu_net_ghg_hist.json')); N90 = H['1990']
def red(k15, k20, k40):
    if k15 is not None and k15 > 0: return (1 - k40 * H['2015'] / k15 / N90) * 100
    if k20: return (1 - k40 * H['2020'] / k20 / N90) * 100
    return None
REL = pd.read_csv('/home/claude/figs/relax_table.csv'); ESB = {r.scenario: r.red2040 for r in REL[REL.source == 'ESABCC 2040 advice'].itertuples()}
X = pd.ExcelFile('/home/claude/r3work/dl/poli/res.xlsx'); f16 = X.parse('Figure 16a (EU)', header=None)
def poli(sc):
    i = f16.index[f16[1] == sc][0]; yrs = f16.iloc[i + 1]; j = i + 2
    while f16.iloc[j, 1] != 'Net GHG emissions': j += 1
    return {int(yrs[c]): float(f16.iloc[j, c]) for c in f16.columns[2:] if pd.notna(yrs[c]) and pd.notna(f16.iloc[j, c])}
def kv(d, v):
    x = d.get(v, {}); return {int(y): (None if (val is None or (isinstance(val, float) and np.isnan(val))) else float(val)) for y, val in x.items()}
rows = []
for l in L:
    s = l['src']; K = {}
    if s in SLUG:
        d = data_for(l) or {}; K = kv(d, 'Emissions|Kyoto Gases')
    elif s in ('Schreyer', 'ElecH2'):
        d = data_for(l) or {}; K = kv(d, 'Emi|GHG|LULUCF national accounting')
    elif s == 'IAMC_GCAM':
        d = data_for(l) or {}; K = kv(d, 'Emissions|Kyoto Gases')
    elif s == 'POLIZERO': K = poli(l['scenario'])
    elif s == 'JRC' and l.get('net50') is not None: K = {2050: l['net50'], 2040: l.get('net40')}
    n50 = K.get(2050); r40 = red(K.get(2015), K.get(2020), K.get(2040)) if K.get(2040) is not None else None
    if s == 'ESABCC' and l['scenario'] in ESB: r40 = ESB[l['scenario']]
    if s == 'JRC' and l.get('red2040') is not None: r40 = l['red2040']
    if l.get('red2040') is not None and s not in ('ESABCC',): r40u = l['red2040']
    rows.append(dict(src=s, pool=l['pool'], model=l['model'], scenario=l['scenario'], new=l['new'], det=l['ind_detail'], net50=n50, red40=r40, red40_u=l.get('red2040'), nz0=l['nz'],
                     cap50=l['cap50'], bio50=l['bio50'], land50=l['land50'], wccs50=l['wccs50'], wbio50=l['wbio50'], h2_30=l['h2_30'], fe_decl=l['fe_decl'],
                     i20=l['v'].get('2020'), i30=l['v'].get('2030'), i40=l['v'].get('2040'), i50=l['v'].get('2050')))
D = pd.DataFrame(rows)
# consistency: our net-zero flag vs universe
chk = D[D.net50.notna()]; print('net50 available', len(chk), 'of', len(D), '| nz mismatch', int(((chk.net50 <= 0) != chk.nz0).sum()))
m = D.red40_u.notna() & D.red40.notna(); print('red diff vs universe (max abs)', round((D[m].red40 - D[m].red40_u).abs().max(), 3))
D.to_csv('variants_base.csv', index=False)
SR = pd.read_csv('/home/claude/dl5/schreyer_screen.csv').set_index('scenario').red40
D['red'] = D.red40
D.loc[D.src == 'Schreyer', 'red'] = D[D.src == 'Schreyer'].scenario.map(SR)
mu = D.red40_u.notna() & (D.src != 'ESABCC'); D.loc[mu, 'red'] = D.loc[mu, 'red40_u']
D['net_ok0'] = np.where(D.net50.notna(), D.net50 <= 0, np.where(D.src == 'JRC', D.nz0, False))
D['net_ok150'] = np.where(D.net50.notna(), D.net50 <= 150, np.where(D.src == 'JRC', D.nz0, False))
TH = dict(cap=500, bio=20, wccs=8600, wbio=240, h2=1.89, fe=20, cap_r=425, bio_r=9, land_r=400)
def tests(r, m):
    f = 1 + m; ex, rk = [], []
    chk = lambda v, t: v is not None and not (isinstance(v, float) and np.isnan(v)) and v > t * f
    if chk(r.cap50, TH['cap']): ex.append('capture')
    if chk(r.bio50, TH['bio']): ex.append('biomass')
    if chk(r.wccs50, TH['wccs']): ex.append('world storage')
    if chk(r.wbio50, TH['wbio']): ex.append('world bioenergy')
    if chk(r.h2_30, TH['h2']): ex.append('hydrogen 2030')
    if chk(r.fe_decl, TH['fe']): ex.append('final energy 2030')
    if chk(r.cap50, TH['cap_r']): rk.append('capture')
    if chk(r.bio50, TH['bio_r']): rk.append('biomass')
    if chk(r.land50, TH['land_r']): rk.append('land sink')
    return ex, rk
WIN = {'85–90%': (84.95, 90.5), '85–95%': (84.95, 95.5), '≥ 85%': (84.95, 1e9)}
OUT = {}; PASS = {}
for nzr in ('0', '150'):
    for wn, (lo, hi) in WIN.items():
        for m in (0.0, 0.1):
            key = f'nz{nzr}|{wn}|m{int(m*100)}'
            st = []
            for r in D.itertuples():
                if not r.det: st.append(-1); continue
                ok = r.net_ok0 if nzr == '0' else r.net_ok150
                if not ok: st.append(0); continue
                if r.red is None or np.isnan(r.red) or not (lo <= r.red < hi): st.append(1); continue
                ex, rk = tests(r, m)
                st.append(2 if ex else (3 if rk else 4))
            st = np.array(st); D[key] = st
            c = [int((st >= 0).sum()), int((st >= 1).sum()), int((st >= 2).sum()), int((st >= 3).sum()), int((st >= 4).sum())]
            P = D[st == 4]; F = D[st >= 3]
            OUT[key] = dict(nz=nzr, win=wn, m=m, counts=c, by_src=P.src.value_counts().to_dict(), filt_by_src=F.src.value_counts().to_dict(),
                            i40=[round(P.i40.min(), 1), round(P.i40.median(), 1), round(P.i40.max(), 1)] if len(P) else None,
                            i50=[round(P.i50.min(), 1), round(P.i50.median(), 1), round(P.i50.max(), 1)] if len(P) else None,
                            new=int((P.new == 1).sum()))
            print(key, c, OUT[key]['by_src'], OUT[key]['i40'])
D.to_csv('variants_all.csv', index=False); json.dump(OUT, open('variants.json', 'w'), ensure_ascii=False, default=float)
