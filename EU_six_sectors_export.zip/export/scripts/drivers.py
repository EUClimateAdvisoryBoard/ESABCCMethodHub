import json, numpy as np, pandas as pd, matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
S = pd.read_csv('/home/claude/pgr/systems_all.csv', low_memory=False)
PURP, TEAL, TEALD, ORANGE, GREY = '#3b2468', '#2a6f97', '#3f6670', '#ec621d', '#7a7a7a'
plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 13, 'axes.spines.top': False, 'axes.spines.right': False, 'axes.spines.left': False, 'axes.edgecolor': '#9a9a9a', 'xtick.color': '#7a7a7a'})
VAR = [(nz, w, 0) for nz in ('0', '150') for w in ('85–90%', '85–95%', '≥ 85%')]
KEY = lambda v: f'nz{v[0]}|{v[1]}|m{v[2]}'
LAB = lambda v: ('★ ' if (v[0]=='150' and v[1]=='85–95%' and v[2]==0) else '') + f"{'net 0' if v[0]=='0' else '≤150'} · {v[1]}{' · +10%' if v[2] else ''}"
SYS = {
 'supply': ('Energy supply', ('sup_e_2040', 'CO₂ 2040', 'Mt CO₂', 786.8, 'inventory 2020'), [('sup_el_2040', 'Electricity generation', 'TWh'), ('sup_wind_2040', 'Wind', 'TWh'), ('sup_solar_2040', 'Solar', 'TWh'), ('sup_h2_2040', 'Hydrogen production', 'EJ')]),
 'industry': ('Industry', ('i40', 'GHG 2040', 'Mt CO₂e', 593.2, 'inventory 2020 (CO₂)'), [('el40', 'Electricity use', 'EJ'), ('h240', 'Hydrogen use', 'EJ'), ('ccs50', 'CO₂ captured, 2050', 'Mt CO₂'), ('fe40', 'Final energy', 'EJ')]),
 'mobility': ('Mobility', ('mob_e_2040', 'CO₂ 2040', 'Mt CO₂', 713.2, 'inventory 2020'), [('mob_fe_2040', 'Final energy', 'EJ'), ('mob_el_2040', 'Electricity use', 'EJ'), ('mob_h2_2040', 'Hydrogen use', 'EJ')]),
 'buildings': ('Built environment', ('bui_e_2040', 'CO₂ 2040', 'Mt CO₂', 418.2, 'inventory 2020'), [('bui_fe_2040', 'Final energy', 'EJ'), ('bui_el_2040', 'Electricity use', 'EJ'), ('bui_gas_2040', 'Gas use', 'EJ')]),
 'agri': ('Agri-food', ('agr_ch4_2040', 'CH₄ 2040', 'Mt CH₄', 8.5, 'inventory 2020'), [('agr_n2o_2040', 'N₂O 2040', 'kt N₂O'), ('agr_ch4_2050', 'CH₄ 2050', 'Mt CH₄'), ('agr_n2o_2050', 'N₂O 2050', 'kt N₂O')]),
 'eco': ('Ecosystems', ('eco_e_2040', 'Net land CO₂ 2040', 'Mt CO₂ (− = sink)', -263.4, 'inventory 2020'), [('eco_e_2050', 'Net land CO₂ 2050', 'Mt CO₂'), ('eco_forest_2040', 'Forest area 2040', 'million ha')]),
}
REF20 = {'sup_el_2040': 'sup_el_2020', 'sup_wind_2040': 'sup_wind_2020', 'sup_solar_2040': 'sup_solar_2020', 'sup_h2_2040': 'sup_h2_2020', 'mob_fe_2040': 'mob_fe_2020', 'mob_el_2040': 'mob_el_2020', 'mob_h2_2040': 'mob_h2_2020',
         'bui_fe_2040': 'bui_fe_2020', 'bui_el_2040': 'bui_el_2020', 'bui_gas_2040': 'bui_gas_2020', 'agr_n2o_2040': None, 'agr_ch4_2050': None, 'agr_n2o_2050': None, 'eco_e_2050': None, 'eco_forest_2040': 'eco_forest_2020'}
INVX = {'agr_n2o_2040': 502.4, 'agr_n2o_2050': 502.4, 'agr_ch4_2050': 8.5, 'eco_e_2050': -263.4}
AV = {}
for sk, (title, em, inds) in SYS.items():
    cols = [em] + [(c, l, u, None, None) for c, l, u in inds]
    f, axs = plt.subplots(1, len(cols), figsize=(17.5, 5.6), sharey=True, gridspec_kw={'width_ratios': [1.6] + [1] * len(inds)})
    AV[sk] = {}
    for j, (c, lab, u, inv, invlab) in enumerate(cols):
        ax = axs[j]; allv = []
        for i, v in enumerate(VAR):
            P = S[S[KEY(v)] == 4]; x = P[c].dropna().values; allv += list(x)
            col = PURP if v[0] == '0' else TEAL
            if j == 0:
                AV[sk][KEY(v)] = [int(len(x)), int(len(P))]
                ax.scatter(x, i + np.random.default_rng(i).uniform(-0.18, 0.18, len(x)), s=26, color=col, alpha=0.75, edgecolor='white', lw=0.4)
            elif len(x):
                ax.plot([x.min(), x.max()], [i, i], color=col, lw=9, solid_capstyle='butt', alpha=0.75); ax.plot([np.median(x)] * 2, [i - 0.3, i + 0.3], color='#1f1f1f', lw=2.2)
            if len(x):
                fm = (lambda z: f'{z:,.0f}') if max(abs(x.min()), abs(x.max())) >= 20 else (lambda z: f'{z:.1f}')
                ax.text(1.0, i, f"{fm(x.min())} to {fm(x.max())}" if x.min() != x.max() else fm(x.min()), transform=ax.get_yaxis_transform(), ha='right', va='center', fontsize=10.5, color='#1f1f1f',
                        bbox=dict(facecolor='white', edgecolor='none', alpha=0.7, pad=1))
            else:
                ax.text(0.5, i, 'not reported', transform=ax.get_yaxis_transform(), ha='center', va='center', fontsize=10, color=GREY)
        ref = inv if inv is not None else INVX.get(c)
        if ref is not None: ax.axvline(ref, color=ORANGE, lw=2, ls='--'); allv.append(ref)
        r20 = REF20.get(c)
        if r20 and r20 in S:
            m20 = S[S[KEY(('0', '≥ 85%', 0))] == 4][r20].dropna()
            if len(m20): ax.axvline(m20.median(), color=GREY, lw=1.5, ls=':'); allv.append(m20.median())
        if allv:
            lo, hi = min(allv + [0]), max(allv + [0]); pad = (hi - lo) * 0.38; ax.set_xlim(lo - (pad * 0.15 if lo < 0 else 0), hi + pad)
        ax.set_title(f"{lab}\n{u}", loc='left', fontsize=14, fontweight='bold', color=TEALD)
        ax.tick_params(axis='y', length=0)
    axs[0].set_yticks(range(len(VAR))); axs[0].set_yticklabels([LAB(v) + f" ({int((S[KEY(v)]==4).sum())})" for v in VAR], fontsize=12.5, color=TEALD, fontweight='bold')
    axs[0].set_ylim(len(VAR) - 0.4, -0.6); axs[0].axhline(2.5, color='#cfcfcf', lw=1)
    for a in axs[1:]: a.axhline(2.5, color='#cfcfcf', lw=1)
    plt.tight_layout(w_pad=1.2); f.savefig(f'drv_{sk}.png', dpi=125, transparent=True); plt.close(f)
json.dump(AV, open('avail6.json', 'w'))
print('ok')
