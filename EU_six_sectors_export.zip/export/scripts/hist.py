import pandas as pd, json
inv = pd.read_csv('/home/claude/dl/inv/x/UNFCCC_33_csv/UNFCCC_v33.csv', encoding='utf-8-sig', low_memory=False); eu = inv[inv.Country_code == 'EUA'].copy(); eu['emissions'] = pd.to_numeric(eu.emissions, errors='coerce')
print(sorted(eu.Pollutant_name.unique())[:20])
def s(codes, pol, y): return float(eu[(eu.Sector_code.isin(codes)) & (eu.Pollutant_name == pol) & (eu.Year == y)].emissions.sum()) / 1000
K = json.load(open('/home/claude/deck/deck7_data.json'))
H = {}
for y in range(2005, 2025):
    H[y] = dict(supply=s(['1.A.1', '1.B'], 'CO2', y), industry=K['hist'].get(str(y)), mobility=s(['1.A.3'], 'CO2', y), buildings=s(['1.A.4.a', '1.A.4.b'], 'CO2', y),
                agri=s(['3'], 'CH4', y) * 28 + s(['3'], 'N2O', y) * 265, eco=s(['4'], 'CO2', y))
json.dump(H, open('hist.json', 'w')); print(H[2005], H[2020], H[2024])
