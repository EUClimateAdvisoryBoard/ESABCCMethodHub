import json, glob, pandas as pd, numpy as np, collections
L = json.load(open('/home/claude/deck/universe6.json'))['lines']
SLUG = {'SC': ['scenariocompass', 'national-scenariocompass'], 'navigate': ['navigate'], 'deeds': ['deeds'], 'ecemf': ['ecemf'], 'CircEUlar': ['circeular'], 'shape': ['shape'],
        'ESABCC': ['eu-climate-advisory-board'], 'ngfs_phase_4': ['ngfs_phase_4'], 'ngfs_phase_5': ['ngfs_phase_5']}
DB = {}
for f in glob.glob('sec_*.csv'):
    slug = f[4:-4]; d = pd.read_csv(f); d = d[d.year.isin([2020, 2030, 2040, 2050])]
    if 'unit' in d:
        d.loc[d.unit == 'PJ/yr', 'value'] = d.loc[d.unit == 'PJ/yr', 'value'] / 1000
        d.loc[d.unit == 'TWh/yr', 'value'] = d.loc[d.unit == 'TWh/yr', 'value'] / 277.78
    for (m, s, r, v), g in d.groupby(['model', 'scenario', 'region', 'variable']):
        DB.setdefault((slug, m, s), {}).setdefault(r, {})[v] = dict(zip(g.year.astype(int), g.value))
import re
def pick(regs, want):
    if want in regs: return want
    order = [r'^EU27$', r'^EU27 \(\*\)$', r'\|EU ?27$', r'^EU-27$', r'^European Union$', r'\|European Union$', r'^European Union and United Kingdom$', r'^EU27 & UK$', r'^EU27 & UK \(\*\)$', r'EU ?28$', r'^European Union \(R9\)$']
    for o in order:
        for r in regs:
            if re.search(o, r): return r
    return None
def wide(df, keycols):
    out = {}
    for _, row in df.iterrows():
        k = tuple(row[c] for c in keycols); out.setdefault(k, {})[row['Variable']] = {y: (float(row[str(y)]) if pd.notna(row.get(str(y))) else None) for y in (2020, 2030, 2040, 2050)}
    return out
sch = pd.read_csv('/home/claude/dl5/schreyer_eu27.csv', low_memory=False); SCH = wide(sch[sch.Region == 'EU27'], ['Scenario'])
el = pd.read_pickle('/home/claude/v4/elech2.pkl'); EL = wide(el[el.Region == 'EU27'], ['Scenario'])
gc = pd.read_pickle('/home/claude/v4/gcam_raw.pkl'); gc = gc[gc.Model == 'GCAM 7.0']
def num(x):
    try: return float(x)
    except: return None
GC = {}
for (st, s), g in gc.groupby(['study', 'Scenario']):
    regs = set(g.Region); eu = g[g.Region == 'EU-27'] if 'EU-27' in regs else g[g.Region.isin(['EU-12', 'EU-15'])]
    key = f"{st.split(' (')[0].replace('IAM COMPACT ', '')}: {s}"
    GC[key] = {v: {y: (pd.to_numeric(x[str(y)], errors='coerce').sum() if str(y) in x and pd.to_numeric(x[str(y)], errors='coerce').notna().any() else None) for y in (2020, 2030, 2040, 2050)} for v, x in eu.groupby('Variable')}
SECT = {
 'Energy supply': dict(E=[['Emissions|CO2|Energy|Supply'], ['Emi|CO2|Energy|+|Supply']], D=[['Secondary Energy|Electricity', 'Secondary Energy|Hydrogen'], ['SE|Electricity', 'SE|Hydrogen']]),
 'Industry': dict(E=[['Emissions|CO2|Energy|Demand|Industry', 'Emissions|CO2|Industrial Processes'], ['Emi|CO2|Energy|Demand|+|Industry', 'Emi|CO2|+|Industrial Processes']], D=[['Final Energy|Industry', 'Final Energy|Industry|Electricity'], ['FE|++|Industry', 'FE|Industry|+|Electricity']]),
 'Mobility': dict(E=[['Emissions|CO2|Energy|Demand|Transportation'], ['Emi|CO2|Energy|Demand|+|Transport']], D=[['Final Energy|Transportation', 'Final Energy|Transportation|Electricity'], ['FE|++|Transport', 'FE|Transport|+|Electricity']]),
 'Built environment': dict(E=[['Emissions|CO2|Energy|Demand|Residential and Commercial'], ['Emi|CO2|Energy|Demand|+|Buildings']], D=[['Final Energy|Residential and Commercial', 'Final Energy|Residential and Commercial|Electricity'], ['FE|++|Buildings', 'FE|Buildings|+|Electricity']]),
 'Agri-food': dict(E=[['Emissions|CH4|AFOLU|Agriculture', 'Emissions|N2O|AFOLU|Agriculture'], ['Emissions|CH4|AFOLU', 'Emissions|N2O|AFOLU'], ['Emi|CH4|+|Agriculture', 'Emi|N2O|+|Agriculture']], D=[['Food Energy Supply|Livestock'], ['Agricultural Production|Livestock']]),
 'Ecosystems': dict(E=[['Emissions|CO2|AFOLU'], ['Emi|CO2|Land-Use Change|LULUCF national accounting']], D=[['Land Cover|Forest']]),
}
POLI_E = {'Energy supply', 'Industry', 'Mobility', 'Built environment', 'Agri-food', 'Ecosystems'}   # Figure 16a sector rows (Mt CO2e); no driver split
def data_for(l):
    s = l['src']
    if s in SLUG:
        for slug in SLUG[s]:
            k = (slug, l['model'], l['scenario'])
            if k in DB:
                r = pick(DB[k], l['region'])
                if r: return DB[k][r]
        return {}
    if s == 'Schreyer': return SCH.get((l['scenario'],), {})
    if s == 'ElecH2': return EL.get((l['scenario'],), {})
    if s == 'IAMC_GCAM': return GC.get(l['scenario'], {})
    return None   # JRC (report values only), POLIZERO handled separately
def has(d, vars_, years):
    return all(v in d and all(d[v].get(y) is not None and not (isinstance(d[v].get(y), float) and np.isnan(d[v].get(y))) for y in years) for v in vars_)
rows = []; missing_lookup = 0
for l in L:
    d = data_for(l)
    rec = dict(pool=l['pool'], src=l['src'], model=l['model'], scenario=l['scenario'], region=l['region'], stage=l['stage'], ind_ok=l['ind_detail'], ghg=l['screenable'])
    if d == {} and l['src'] in SLUG: missing_lookup += 1
    for sec, sp in SECT.items():
        if l['src'] == 'POLIZERO': e, dd, ev = sec in POLI_E, False, 'POLIZERO Fig 16a'
        elif d is None: e, dd, ev = False, False, None
        else:
            ev = next((alt for alt in sp['E'] if has(d, alt, (2020, 2050))), None); e = ev is not None
            dv = next((alt for alt in sp['D'] if has(d, alt, (2040,))), None); dd = e and dv is not None
        rec[sec + '|E'] = e; rec[sec + '|D'] = dd
    rows.append(rec)
R = pd.DataFrame(rows); print('lines without lookup data', missing_lookup)
R.to_csv('sector_avail.csv', index=False)
steps = [('All pathways', R.index == R.index), ('Net zero 2050', R.stage >= 1), ('Cut 85–90% 2040', R.stage >= 2), ('ESABCC filter', R.stage >= 3), ('Risk levels', R.stage >= 4)]
T = {}
for sec in SECT:
    T[sec] = {lab: [int((m & R[sec + '|E']).sum()), int((m & R[sec + '|D']).sum()), int(m.sum())] for lab, m in steps}
print(json.dumps(T, indent=0, ensure_ascii=False))
json.dump(T, open('sector_funnel.json', 'w'), ensure_ascii=False)
print(R[R.src.isin(SLUG) & ~R['Mobility|E']].groupby('pool').size())
