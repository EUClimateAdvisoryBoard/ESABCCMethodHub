import json, numpy as np, pandas as pd, matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
S = pd.read_csv('/home/claude/pgr/systems_all.csv', low_memory=False); O = json.load(open('netghg_series.json'))
H = {int(k): v for k, v in json.load(open('/home/claude/figs/eu_net_ghg_hist.json')).items()}
Y = [2020, 2030, 2040, 2050]; M = np.array([[r['K'].get(str(y)) if r['K'].get(str(y)) is not None else np.nan for y in Y] for r in O], dtype=float)
st = S['nz150|85–95%|m0'].values
PURP, TEAL, TEALD, ORANGE, GREY = '#3b2468', '#608c95', '#3f6670', '#ec621d', '#7a7a7a'
plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 15, 'axes.spines.top': False, 'axes.spines.right': False, 'axes.edgecolor': '#9a9a9a', 'xtick.color': '#7a7a7a', 'ytick.color': '#7a7a7a'})
steps = [('Pathways collected', np.ones(len(S), bool)), ('With industry data', st >= 0), ('EU net GHG ≤ 150 Mt CO₂e in 2050', st >= 1),
         ('2040 net GHG cut 85–95% vs 1990', st >= 2), ('ESABCC filter (feasibility, Table 5)', st >= 3), ('Risk levels (sustainability, Table 6)', st == 4)]
# funnel
f, ax = plt.subplots(figsize=(17, 6.6)); cols = ['#cfcfcf', '#b9c9cc', '#97b4ba', TEAL, TEALD, PURP]
for i, ((lab, m), c) in enumerate(zip(steps, cols)):
    y = len(steps) - 1 - i; n = int(m.sum()); ax.barh(y, n, color=c, height=0.66)
    ax.text(n + 12, y, f'{n:,}', va='center', fontsize=26, fontweight='bold', color=c if i > 1 else '#6b6b6b')
    ax.text(-15, y, lab, va='center', ha='right', fontsize=19, color='#474747', fontweight='bold' if i == 5 else 'normal')
ax.set_xlim(0, 1500); ax.set_yticks([]); ax.spines['left'].set_visible(False); ax.set_xlabel('pathways', fontsize=14)
plt.tight_layout(); f.savefig('econ_funnel.png', dpi=120, transparent=True); plt.close(f)
# medians per step
f, ax = plt.subplots(figsize=(17, 7.6))
hy = [y for y in H if y >= 1990]; ax.bar(hy, [H[y] for y in hy], color='#dfe9eb', width=0.8, label='EEA inventory, EU net GHG 1990–2024')
NN = {}
for i, ((lab, m), c) in enumerate(zip(steps[1:], cols[1:])):
    msk = m & ~np.isnan(M).any(axis=1); P = M[msk]; md = np.median(P, axis=0); NN[lab] = int(msk.sum())
    if i == 4:
        ax.fill_between(Y, np.percentile(P, 25, axis=0), np.percentile(P, 75, axis=0), color=PURP, alpha=0.18, lw=0, label='25–75% of the 64')
        for y, v in zip(Y[1:], md[1:]): ax.text(y + 0.6, v + 90, f'{v:,.0f}', ha='left', fontsize=17, fontweight='bold', color=PURP)
    ax.plot(Y, md, color=c, lw=4 if i == 4 else 2.5, marker='o', ms=7, label=f'{lab} ({msk.sum():,}): median')
ax.axhline(0, color='#1f1f1f', lw=0.8); ax.set_xlim(1988, 2053); ax.set_ylabel('Mt CO₂e'); ax.set_xticks([1990, 2000, 2010, 2020, 2030, 2040, 2050])
ax.legend(frameon=False, fontsize=13.5, loc='upper right'); plt.tight_layout(); f.savefig('econ_medians.png', dpi=120, transparent=True); plt.close(f)
json.dump(dict(steps=[(l, int(m.sum())) for l, m in steps], nmed=NN, by_src=S[st == 4].src.value_counts().to_dict()), open('econ.json', 'w'), indent=1); print(open('econ.json').read())
