import json, base64, re
B = open('/home/claude/tdeck/build.py').read()
CSS = re.search(r'CSS = """(.*?)"""', B, re.S).group(1); JS = re.search(r'JS = """(.*?)"""', B, re.S).group(1)
CSS += """.cards{display:grid;grid-template-columns:repeat(3,1fr);gap:22px;margin-top:26px;flex:1}.card{background:#eef3f4;border-top:6px solid #608c95;padding:18px 24px}
.card h3{font-size:27px;color:#3f6670;margin-bottom:4px}.card .r{font-size:19px;color:#7a7a7a;margin-bottom:10px}.card .r b{color:#3b2468;font-size:22px}
.lv{display:flex;justify-content:space-between;align-items:baseline;border-bottom:1px solid #d6e2e4;padding:7px 0;font-size:20px;color:#474747}.lv span:last-child{font-weight:800;color:#3b2468;font-size:24px}.lv em{font-style:normal;color:#9a9a9a;font-size:16px}
.big{display:flex;gap:26px;margin-top:22px}.big div{flex:1;background:#eef3f4;padding:14px 20px;border-left:6px solid #3b2468}.big b{display:block;font-size:44px;color:#3b2468;font-weight:800}.big span{font-size:18px;color:#474747}
table.t td.n{text-align:right;font-weight:700;color:#3b2468}"""
img = lambda f: 'data:image/png;base64,' + base64.b64encode(open(f, 'rb').read()).decode()
O = json.load(open('out.json')); X = json.load(open('out2.json')); L, LEV = X['L'], X['LEV']
NAME = {'supply': 'Energy supply', 'industry': 'Industry', 'mobility': 'Mobility', 'buildings': 'Built environment', 'agri': 'Agri-food', 'eco': 'Ecosystems'}
UNIT = {'agri': 'Mt CO₂e', 'industry': 'Mt CO₂e', 'eco': 'Mt CO₂'}
VAR = {'supply': 'Emissions|CO2|Energy|Supply', 'industry': 'industry GHG harmonised to the 2020 inventory (main deck)', 'mobility': 'Emissions|CO2|Energy|Demand|Transportation',
       'buildings': 'Emissions|CO2|Energy|Demand|Residential and Commercial', 'agri': 'Emissions|CH4|AFOLU|Agriculture × 28 + Emissions|N2O|AFOLU|Agriculture × 0.265 (kt)', 'eco': 'Emissions|CO2|AFOLU'}
INV = {'supply': 'CRF 1.A.1 + 1.B, CO₂', 'industry': 'industry GHG (main deck)', 'mobility': 'CRF 1.A.3, CO₂', 'buildings': 'CRF 1.A.4.a + 1.A.4.b, CO₂', 'agri': 'CRF 3, CH₄ and N₂O', 'eco': 'CRF 4, CO₂'}
f0 = lambda v: f'{v:,.0f}'.replace('-', '−')
S = []
S.append("""<section class="slide dark"><h1>Six sectors in EU scenario pathways: emissions to 2050 under the 2040 screening settings</h1><p>Energy supply · Industry · Mobility · Built environment · Agri-food · Ecosystems</p><p style="font-size:22px;margin-top:60px">EEA for the ESABCC Secretariat · 20 November 2026 · internal: Scenario Compass data under embargo</p></section>""")
E = json.load(open('econ.json')); src64 = ', '.join(f"{ {'Schreyer': 'Schreyer et al. 2025', 'SC': 'Scenario Compass', 'ESABCC': 'ESABCC 2023', 'ngfs_phase_5': 'NGFS 5', 'ngfs_phase_4': 'NGFS 4', 'ElecH2': 'Schreyer et al. 2024', 'deeds': 'DEEDS', 'ecemf': 'ECEMF', 'navigate': 'NAVIGATE'}.get(k, k)} {v}" for k, v in E['by_src'].items())
S.append(f"""<section class="slide"><p class="kicker">Economy-wide · screening</p><h2>From 1,328 pathways to 64</h2><p class="lead">Setting of the 2040 advice; each step applied to the pathways left after the previous one</p><div class="fig"><img src="{img('econ_funnel.png')}"></div><p class="src">The 64: {src64}. 2040 cut: ESABCC runs use the Board's metric; other pathways: net GHG scaled to the 2015 inventory (2020 where 2015 is missing). Missing values count as passed.</p></section>""")
S.append(f"""<section class="slide"><p class="kicker">Economy-wide · EU net GHG</p><h2>Median EU net GHG at each screening step</h2><p class="lead">Number of pathways in each median in brackets; the 64 filtered pathways in purple</p><div class="fig"><img src="{img('econ_medians.png')}"></div><p class="src">Emissions|Kyoto Gases (REMIND-EU: Emi|GHG|LULUCF national accounting), as reported; only pathways reporting 2020, 2030, 2040 and 2050. Model regions differ (EU27, EU27 and UK), so 2020 values are above the EU inventory.</p></section>""")
for i, sk in enumerate(NAME, 1):
    l, o = L[sk], O[sk]; u = UNIT.get(sk, 'Mt CO₂')
    S.append(f"""<section class="slide"><p class="kicker">Sector {i} of 6</p><h2>{NAME[sk]}</h2><p class="lead">Median curve from <b style="color:#3b2468">{l['n']} of the 64 filtered pathways</b>{'' if l['n'] == 64 else f" ({64 - l['n']} do not report this sector)"}</p>
<div class="big" style="margin-top:14px"><div><b>{f0(l['med50'])}</b><span>{u} in 2050, median of {l['n']} filtered pathways</span></div><div><b>{f0(l['p25'])} to {f0(l['p75'])}</b><span>2050, 25–75% of the filtered pathways</span></div><div style="border-color:#ec621d"><b style="color:#ec621d">{f0(l['lo'])} to {f0(l['hi'])}</b><span>2050 median across the six settings</span></div><div style="border-color:#97b4ba"><b style="color:#3f6670">{f0(l['inv24'])}</b><span>inventory 2024 · models 2020: {f0(o['m20'])} vs inventory {f0(o['inv20'])}</span></div></div>
<div class="fig"><img src="{img(sk + '_main.png')}"></div><p class="src">Filtered pathways: EU net GHG ≤ 150 Mt CO₂e in 2050, 2040 cut 85–95%, ESABCC filter and risk levels. {o['rep']} pathways report this sector. Variable: {VAR[sk]}. Inventory: {INV[sk]}.</p></section>""")
def lev(d):
    if not d['n']: return f"<div class='lv'><span>{d['lab']}</span><span><em>not reported</em></span></div>"
    def g(v): return f'{v:,.2f}' if abs(v) < 1 else (f'{v:,.1f}' if abs(v) < 100 else f'{v:,.0f}')
    val = (f"{g(d['a'])} → {g(d['b'])}" if d['a'] is not None else f"{g(d['b'])} <em>({d['y']})</em>").replace('-', '−')
    return f"<div class='lv'><span>{d['lab']} <em>{d['u']} · n={d['n']}</em></span><span>{val}</span></div>"
UL = dict(LEV); 
for d in UL['supply'][:2]: d['u'] = 'TWh'
cards = ''.join(f"<div class='card'><h3>{NAME[sk]}</h3><p class='r'>2050 residual, median: <b>{f0(L[sk]['med50'])} {UNIT.get(sk, 'Mt CO₂')}</b></p>{''.join(lev(d) for d in UL[sk])}</div>" for sk in NAME)
S.append(f"""<section class="slide"><p class="kicker">Levers</p><h2>What changes by 2050 in the filtered pathways</h2><p class="lead">Median of the 64 filtered pathways, 2020 → 2050 as reported; industry energy only available for 2040</p><div class="cards">{cards}</div>
<p class="src">Wind and solar: Secondary Energy|Electricity|Wind, |Solar, converted from EJ to TWh (× 277.78). Hydrogen production: Secondary Energy|Hydrogen. Mobility and buildings: Final Energy|Transportation, |Residential and Commercial, |Electricity, |Hydrogen, |Gases. Industry: Final Energy|Industry|Electricity, |Hydrogen; Carbon Capture|Industry (main deck, test 2). Livestock: Food Energy Supply|Livestock. Forest: Land Cover|Forest.</p></section>""")
rows = ''.join(f"<tr><td><b>{NAME[sk]}</b></td><td>{VAR[sk]}</td><td>{INV[sk]}</td><td class='n'>{O[sk]['rep']:,}</td><td class='n'>{L[sk]['n']}</td><td class='n'>{f0(O[sk]['m20'])}</td><td class='n'>{f0(O[sk]['inv20'])}</td></tr>" for sk in NAME)
S.append(f"""<section class="slide"><p class="kicker">Method and data</p><h2>Screening and sector data</h2>
<div class="rules" style="grid-template-columns:repeat(4,1fr);margin-top:24px"><div><h3>1 · Net GHG 2050</h3><p>EU net GHG ≤ 0, or ≤ 150 Mt CO₂e</p></div><div><h3>2 · 2040 window</h3><p>Net GHG cut vs 1990: 85–90%, 85–95% or ≥ 85% (rounded)</p></div><div><h3>3 · ESABCC filter</h3><p>Feasibility limits, ESABCC (2023) Table 5</p></div><div><h3>4 · Risk levels</h3><p>Sustainability limits, ESABCC (2023) Table 6</p></div></div>
<table class="t"><tr><th>Sector</th><th>Scenario variable</th><th>Inventory</th><th>Pathways reporting</th><th>Filtered</th><th>2020 models (median)</th><th>2020 inventory</th></tr>{rows}</table>
<p class="src" style="margin-top:14px">Pathways: IIASA scenario databases (Scenario Compass v2.0, National Scenario Compass, NAVIGATE, ECEMF, CircEUlar, SHAPE, DEEDS, ESABCC 2023, NGFS 4 and 5), Schreyer et al. (2025), JRC, POLIZERO. Missing values count as passed. Only industry is harmonised to the inventory; the other sectors are shown as reported. CO₂e with AR5 GWP (CH₄ 28, N₂O 265). Inventory: EEA (2026), UNFCCC submission, EU. Filtered: net GHG ≤ 150 Mt, 85–95%.</p></section>""")
S.append(f"""<section class="slide"><p class="kicker">Open question</p><h2>2050 sector emissions by setting</h2><p class="lead">Median of the pathways within all criteria; orange ring: setting of the 2040 advice (net GHG ≤ 150 Mt, 85–95%). No filtered pathway is above 95%, so 85–95% and ≥ 85% give the same set.</p><div class="fig"><img src="{img('settings_all.png')}"></div><p class="src">Net GHG ≤ 0 · 85–90%: two pathways only. Units as on the sector slides.</p></section>""")
S.append("""<section class="slide dark"><h1>Appendix</h1><p>Each sector under the six settings</p></section>""")
for sk in NAME:
    S.append(f"""<section class="slide"><p class="kicker">Appendix · {NAME[sk]}</p><h2>{NAME[sk]} under six settings</h2><p class="lead">Pathways within all criteria: median, 25–75%, 5–95%; orange frame: setting of the 2040 advice</p><div class="fig"><img src="{img(sk + '_settings.png')}"></div><p class="src">Bars: EEA inventory 2005–2024. Fewer than five pathways: single lines.</p></section>""")
n = len(S)
body = ''.join(s.replace('</section>', f'<div class="ctr">{i+1} / {n}</div></section>') for i, s in enumerate(S))
open('six_sectors_deck.html', 'w').write(f'<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><title>Six sectors in EU scenario pathways</title><style>{CSS}</style></head><body><div id="stage">{body}</div><script>{JS}</script></body></html>')
print(n)
