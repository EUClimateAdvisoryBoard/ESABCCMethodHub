import json, glob, re, pandas as pd, numpy as np
exec(open("sector_avail.py").read().split("rows = []")[0])
V = pd.read_csv('variants_all.csv')
SPEC = {  # key: (IAMC vars, REMIND vars, factor)
 'sup_e': (['Emissions|CO2|Energy|Supply'], ['Emi|CO2|Energy|+|Supply'], 1),
 'sup_el': (['Secondary Energy|Electricity'], ['SE|Electricity'], 277.78),
 'sup_wind': (['Secondary Energy|Electricity|Wind'], ['SE|Electricity|+|Wind'], 277.78),
 'sup_solar': (['Secondary Energy|Electricity|Solar'], ['SE|Electricity|+|Solar'], 277.78),
 'sup_h2': (['Secondary Energy|Hydrogen'], ['SE|Hydrogen'], 1),
 'mob_e': (['Emissions|CO2|Energy|Demand|Transportation'], ['Emi|CO2|Energy|Demand|+|Transport'], 1),
 'mob_fe': (['Final Energy|Transportation'], ['FE|++|Transport'], 1),
 'mob_el': (['Final Energy|Transportation|Electricity'], ['FE|Transport|+|Electricity'], 1),
 'mob_h2': (['Final Energy|Transportation|Hydrogen'], ['FE|Transport|+|Hydrogen'], 1),
 'bui_e': (['Emissions|CO2|Energy|Demand|Residential and Commercial'], ['Emi|CO2|Energy|Demand|+|Buildings'], 1),
 'bui_fe': (['Final Energy|Residential and Commercial'], ['FE|++|Buildings'], 1),
 'bui_el': (['Final Energy|Residential and Commercial|Electricity'], ['FE|Buildings|+|Electricity'], 1),
 'bui_gas': (['Final Energy|Residential and Commercial|Gases'], ['FE|Buildings|+|Gases'], 1),
 'agr_ch4': (['Emissions|CH4|AFOLU|Agriculture'], ['Emi|CH4|+|Agriculture'], 1),
 'agr_n2o': (['Emissions|N2O|AFOLU|Agriculture'], ['Emi|N2O|+|Agriculture'], 1),
 'agr_live': (['Food Energy Supply|Livestock'], [], 1),
 'eco_e': (['Emissions|CO2|AFOLU'], ['Emi|CO2|Land-Use Change|LULUCF national accounting'], 1),
 'eco_forest': (['Land Cover|Forest'], [], 1),
}
def val(d, vs, y):
    if not vs or not all(v in d and d[v].get(y) is not None for v in vs): return None
    x = sum(float(d[v][y]) for v in vs); return None if np.isnan(x) else x
rows = []
for l, (_, vr) in zip(L, V.iterrows()):
    d = data_for(l) or {}; rec = {}
    for k, (iv, rv, f) in SPEC.items():
        vs = rv if l['src'] in ('Schreyer', 'ElecH2') else iv
        for y in (2020, 2030, 2040, 2050):
            x = val(d, vs, y); rec[f'{k}_{y}'] = None if x is None else x * f
    rows.append(rec)
S = pd.concat([V, pd.DataFrame(rows)], axis=1)
O = pd.read_csv('options_all.csv')[['fe40', 'el40', 'h240', 'ccs50', 'pr40']]
S = pd.concat([S, O], axis=1)
S.to_csv('systems_all.csv', index=False)
keys = [c for c in V.columns if c.startswith('nz')]
for k in keys:
    P = S[S[k] == 4]; print(k, len(P), {c: int(P[c].notna().sum()) for c in ['sup_e_2040', 'sup_wind_2040', 'mob_e_2040', 'mob_el_2040', 'bui_e_2040', 'agr_ch4_2040', 'agr_live_2040', 'eco_e_2040', 'eco_forest_2040']})
