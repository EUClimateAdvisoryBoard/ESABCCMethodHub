import json, numpy as np, pandas as pd, matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
S = pd.read_csv('/home/claude/pgr/systems_all.csv', low_memory=False); H = {int(k): v for k, v in json.load(open('hist.json')).items()}
K = json.load(open('/home/claude/deck/deck7_data.json'))
Y = [2020, 2030, 2040, 2050]
cols = {}
for y in Y:
    cols[f'industry_{y}'] = S[{2020: 'i20', 2030: 'i30', 2040: 'i40', 2050: 'i50'}[y]]
    cols[f'supply_{y}'] = S[f'sup_e_{y}']; cols[f'mobility_{y}'] = S[f'mob_e_{y}']; cols[f'buildings_{y}'] = S[f'bui_e_{y}']
    cols[f'agri_{y}'] = S[f'agr_ch4_{y}'] * 28 + S[f'agr_n2o_{y}'] * 0.265; cols[f'eco_{y}'] = S[f'eco_e_{y}']
E_ = pd.DataFrame(cols)
PURP, TEAL, TEALD, TEALL, ORANGE, RED, GREY = '#3b2468', '#608c95', '#3f6670', '#97b4ba', '#ec621d', '#a84048', '#7a7a7a'
plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 14, 'axes.spines.top': False, 'axes.spines.right': False, 'axes.edgecolor': '#9a9a9a', 'xtick.color': '#7a7a7a', 'ytick.color': '#7a7a7a'})
SEC = {'supply': ('Energy supply', 'Mt CO₂', (-700, 1500)), 'industry': ('Industry', 'Mt CO₂e', (-150, 950)), 'mobility': ('Mobility', 'Mt CO₂', (-50, 1000)),
       'buildings': ('Built environment', 'Mt CO₂', (-50, 650)), 'agri': ('Agri-food', 'Mt CO₂e (CH₄ × 28 + N₂O × 265)', (0, 650)), 'eco': ('Ecosystems', 'Mt CO₂ (negative = sink)', (-700, 450))}
VAR = [(nz, w) for nz in ('0', '150') for w in ('85–90%', '85–95%', '≥ 85%')]
KEY = lambda v: f'nz{v[0]}|{v[1]}|m0'
OUT = {}
for sk, (name, unit, yl) in SEC.items():
    M = E_[[f'{sk}_{y}' for y in Y]].values; rep = ~np.isnan(M).any(axis=1) & (S[KEY(('0', '≥ 85%'))].values >= 0)
    # (a) data slide
    f, ax = plt.subplots(figsize=(17, 7.2))
    ax.bar(list(H), [H[y][sk] for y in H], color='#cfdde0', width=0.8, zorder=1, label='EEA inventory')
    nzm = rep & (S['nz150|≥ 85%|m0'].values >= 1)
    for msk, col, lab, al in ((rep, '#9b9b9b', f'all pathways reporting ({rep.sum()})', 0.35), (nzm, TEAL, f'net GHG ≤ 150 Mt in 2050 ({nzm.sum()})', 0.55)):
        Q = {p: np.nanpercentile(M[msk], p, axis=0) for p in (5, 25, 50, 75, 95)}
        ax.fill_between(Y, Q[5], Q[95], color=col, alpha=al * 0.5, lw=0, zorder=2); ax.fill_between(Y, Q[25], Q[75], color=col, alpha=al, lw=0, zorder=3)
        ax.plot(Y, Q[50], color=col if col != '#9b9b9b' else '#6b6b6b', lw=3, zorder=4, label=lab + ': median, 25–75%, 5–95%')
    m20 = np.nanmedian(M[rep][:, 0]); ax.scatter([2020], [m20], marker='D', s=90, color=PURP, zorder=5, label=f'2020 in the models (all): median {m20:,.0f} · inventory {H[2020][sk]:,.0f}')
    ax.axhline(0, color='#1f1f1f', lw=0.8); ax.set_ylim(*yl); ax.set_xlim(2004, 2052); ax.set_ylabel(unit); ax.legend(loc='upper right', frameon=False, fontsize=13)
    plt.tight_layout(); f.savefig(f'{sk}_data.png', dpi=120, transparent=True); plt.close(f)
    # (c) settings
    f, axs = plt.subplots(2, 3, figsize=(17, 8.4), sharex=True, sharey=True); OUT[sk] = {'rep': int(rep.sum()), 'nzrep': int(nzm.sum()), 'm20': float(m20), 'inv20': H[2020][sk], 'inv24': H[2024][sk]}
    for k, v in enumerate(VAR):
        ax = axs[k // 3, k % 3]; P = M[(S[KEY(v)].values == 4) & ~np.isnan(M).any(axis=1)]
        ax.bar(list(H), [H[y][sk] for y in H], color='#dfe9eb', width=0.8)
        n = len(P); OUT[sk][KEY(v)] = {'n': n, 'npass': int((S[KEY(v)] == 4).sum())}
        if n >= 5:
            q = {p: np.percentile(P, p, axis=0) for p in (5, 25, 50, 75, 95)}
            ax.fill_between(Y, q[5], q[95], color=TEALL, alpha=0.5, lw=0); ax.fill_between(Y, q[25], q[75], color=TEAL, alpha=0.8, lw=0); ax.plot(Y, q[50], color=PURP, lw=3)
            ax.text(2040, q[50][2], f'{q[50][2]:,.0f}', fontsize=13, fontweight='bold', color=PURP, ha='right', va='bottom'); ax.text(2050.5, q[50][3], f'{q[50][3]:,.0f}', fontsize=13, fontweight='bold', color=PURP, va='center')
            OUT[sk][KEY(v)].update(med40=float(q[50][2]), med50=float(q[50][3]), p5_50=float(q[5][3]), p95_50=float(q[95][3]), p5_40=float(q[5][2]), p95_40=float(q[95][2]))
        else:
            for row in P: ax.plot(Y, row, color=PURP, lw=2)
            if n: OUT[sk][KEY(v)].update(vals40=[float(x) for x in P[:, 2]], vals50=[float(x) for x in P[:, 3]])
        ax.axhline(0, color='#1f1f1f', lw=0.8); ax.set_ylim(*yl); ax.set_xlim(2004, 2054)
        ax.set_title(f"{'Net GHG ≤ 0' if v[0] == '0' else 'Net GHG ≤ 150 Mt'} · 2040 cut {v[1]}", loc='left', fontsize=14, fontweight='bold', color=(ORANGE if KEY(v) == 'nz150|85–95%|m0' else TEALD))
        ax.text(0.98, 0.95, f'n = {n}', transform=ax.transAxes, ha='right', va='top', fontsize=15, fontweight='bold', color=PURP)
        if KEY(v) == 'nz150|85–95%|m0':
            for sp in ax.spines.values(): sp.set_visible(True); sp.set_edgecolor(ORANGE); sp.set_linewidth(3)
    for a in axs[:, 0]: a.set_ylabel(unit, fontsize=12)
    plt.tight_layout(h_pad=1.5); f.savefig(f'{sk}_settings.png', dpi=120, transparent=True); plt.close(f)
json.dump(OUT, open('out.json', 'w'), indent=1); print(json.dumps({k: {kk: vv for kk, vv in v.items() if kk in ('rep', 'nzrep', 'm20', 'inv20', 'nz150|85–95%|m0')} for k, v in OUT.items()}, indent=0)[:2500])
